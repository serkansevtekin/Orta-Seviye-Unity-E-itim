using UnityEngine;

public class BirimVektorBulmaNormalize : MonoBehaviour
{
   
    Vector3 v = new Vector3(4,3,0);

    Vector3 birimVector;
    void Start()
    {
        birimVector = v.normalized; // normalized, vektörü birim vektöre dönüştürür; sonuç vektörün magnitude’i 1 olur ve bileşenleri -1 ile +1 arasında kalır. Normalize = vektörün yönünü koruyup uzunluğunu 1 yapmak.

        Debug.Log("Normal değişken v " + v);
        Debug.Log("v.normailzed uygulanan birimVector "+ birimVector);
        
        v.Normalize(); // Bu bir metod ve orijinal vektörü kendisi değiştirir.
        Debug.Log("v.Normalize() ile değişen v " + v);
    }

}
