using UnityEngine;

public class HazirVectorler : MonoBehaviour
{
    // Vector3.zero  -> Vector3(0,0,0)
    // Vecror3.one   -> Vector3(1,1,1)

    // Vector3.right -> Vector3(1,0,0)
    // Vector3.left  -> Vector3(-1,0,0)

    // Vector3.up    -> Vector3(0,1,0)
    // Vector3.down  -> Vector3(0,-1,0)

    // Vector3.forward -> Vector3(0,0,1)
    // Vector3.back    -> Vector3(0,0,-1)

    Rigidbody rb;
    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }
    void Update()
    {
        //   transform.position += Vector3.forward * 4f * Time.deltaTime;
        if (Input.GetKeyDown(KeyCode.Space))
        {
                rb.AddForce(Vector3.up * 1000f); // yukarı yönde güç uygula
        }
        rb.linearVelocity = Vector3.zero; // rb'nin tüm hareket hızını anında sıfırlar
        rb.angularVelocity = Vector3.zero; // rb'nin dönme hızını sıfırlar
    }
}
