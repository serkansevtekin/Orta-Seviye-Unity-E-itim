using UnityEngine;

public class KupControlManager : MonoBehaviour
{
    Vector3 a = new Vector3(1,2,3);
    Vector3 b = new Vector3(2,3,4);

    Vector3 toplam;
    Vector3 fark;
    Vector3 carpim;

    void Start()
    {
        toplam = a+b;
        Debug.Log(toplam);

        fark = a-b;
        Debug.Log(fark);

        carpim = 2*a + b;
        Debug.Log(carpim);
    }
}