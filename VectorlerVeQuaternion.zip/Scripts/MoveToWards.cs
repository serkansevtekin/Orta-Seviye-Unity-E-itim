using UnityEngine;

public class MoveToWards : MonoBehaviour
{
public Transform playerTransform;

public float moveSpeed = 2f;
public float hareketeBaslamaMesafesi=5f;
public float durmaMesafesi=2f;

    void Update()
    {
        // mesafeyi ölç (Vector3.Distance)
        float mesafe = Vector3.Distance(playerTransform.position,transform.position);

        //hareket mesafesi aralıktamı
        if (mesafe < hareketeBaslamaMesafesi && mesafe > durmaMesafesi)
        {
            //Vector3.MoveTowards() -> belli bir hızda ve keskin bir mesafede başka bir hedefe doğru doğrusal olarak hareket et
            transform.position = Vector3.MoveTowards(transform.position,playerTransform.position, moveSpeed * Time.deltaTime);
        }

    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.black;
        Gizmos.DrawWireSphere(transform.position,hareketeBaslamaMesafesi);

        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position,durmaMesafesi);

        
    }
}
