using Unity.Mathematics;
using UnityEngine;

public class QuaternionKullanimi : MonoBehaviour
{
    public Transform hedef;
    public float donmeHizi = 3f;

    void Update()
    {
        Quaternion mevcutRotation = transform.rotation;

        Quaternion estraRotation = Quaternion.Euler(0f, 90f * donmeHizi * Time.deltaTime, 0f);

        transform.rotation = mevcutRotation * estraRotation;
    }
}
