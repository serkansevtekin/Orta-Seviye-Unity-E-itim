using UnityEngine;

public class VectorlerArasıMesafe : MonoBehaviour
{
    public Transform enemyTransform;
    float mesafe;

    // Vector3 directionVector;



    void Update()
    {
        if (enemyTransform == null) return;

        mesafe = Vector3.Distance(transform.position, enemyTransform.position);


        Debug.Log(mesafe);
        
        if (mesafe < 2f)
        {
            Destroy(enemyTransform.gameObject);
        }


        //2. yol -> 1. yol enmantıklı yol Vector3.Distance() bütün bu işlemleri arkada zaten yapıyor 

        /*       if (enemyTransform == null)
              {
                  return;
              }

              // ör: A ile B pozisyonu arasındaki farkı alıp directionVector'a aktar
              directionVector = transform.position - enemyTransform.position;

              // Bu fark'ın uzunluğunu hesaplamak için magintude kullanılır
              mesafe = directionVector.magnitude; 

            Debug.Log(mesafe);
              if (mesafe < 2f)
              {

                  Destroy(enemyTransform.gameObject);


              } */


    }
}
