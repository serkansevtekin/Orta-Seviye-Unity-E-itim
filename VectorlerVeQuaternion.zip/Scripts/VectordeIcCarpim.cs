using UnityEngine;

public class VectordeIcCarpim : MonoBehaviour
{
    public Transform player;
    public Renderer renderers;

    void Update()
    {


        // dusmandan oyuncuya yön hesabı
        Vector3 hedefYon = player.position - transform.position;

        //vetörü sadece yön için kullanacağımız için  Normalize() yapıyoruz
        hedefYon.Normalize();

        //Düşmanın ileri yönü
        Vector3 enemyForward = transform.forward;

        // Dot product (İç çarpım ) 
        //Dot product -> iki adet Vector3 arasındaki skaler çarpımı hesaplamak için kullanılır.
        //Vector3.Dot metodu ile iki vektör arasındaki açıyı belirleyebiliriz. 
        //Ancak, Vector3.Dot metodu doğrudan açıyı derece ($\text{degree}$) veya radyan ($\text{radian}$) cinsinden vermez. Bunun yerine, açının kosinüs ($\cos(\theta)$) değerini döndürür.
        float dot = Vector3.Dot(enemyForward, hedefYon);

        if (dot > 0.9f)
        {
            renderers.material.color = Color.black; // oyuncuya bakıyorsa
        }
        else
        {
            renderers.material.color = Color.green; // oyuncuya bakmıyor
        }


        //Debug çizgisi yönleri görmek için (Sadece scene View de gözükür)
        Debug.DrawRay(transform.position, enemyForward * 2, Color.blue); // ileri yön

        Debug.DrawRay(transform.position, hedefYon * 2, Color.yellow); // hedef yön 
    }
}
