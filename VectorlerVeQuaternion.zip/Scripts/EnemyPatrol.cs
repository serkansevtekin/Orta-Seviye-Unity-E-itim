using System;
using UnityEngine;

public class EnemyPatrol : MonoBehaviour
{
    public Transform[] patrolNoktalari;
    public float hareketHizi = 3f;
    public float hedefeVarmaMesafesi = 0.3f;

    public float beklemeSuresi = 2f;

    float beklemeSayaci = 0f;
    int currentIndex;

    void Update()
    {
        if (beklemeSayaci >0f)
        {
            beklemeSayaci -= Time.deltaTime;

        }
        else
        {
            PatrolYap();
        }
        
    }

    private void PatrolYap()
    {
        if (patrolNoktalari.Length == 0) return;

        //Vector3 hedefPos = patrolNoktalari[currentIndex].position;
        Vector3 hedefPos = new Vector3(patrolNoktalari[currentIndex].position.x,transform.position.y,patrolNoktalari[currentIndex].position.z);

        transform.LookAt(hedefPos);

        transform.position = Vector3.MoveTowards(transform.position, hedefPos, hareketHizi * Time.deltaTime);
        
        float mesafe = Vector3.Distance(transform.position,hedefPos);

        if (mesafe < hedefeVarmaMesafesi)
        {
            beklemeSayaci = beklemeSuresi;
            //Bir sonraki devriye noktasona geç
            //Mod % operatörü, dizin (index)  dizinin sonuna ulaştığında (kalan yok ise)
            // Otomatik olarak başa dön
            currentIndex =(currentIndex + 1) % patrolNoktalari.Length;

          /*   currentIndex++;
            if (currentIndex >= patrolNoktalari.Length)
            {
                currentIndex = 0;
            } */
        }
    }
}
