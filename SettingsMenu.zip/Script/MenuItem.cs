using UnityEngine;

public class MenuItem : MonoBehaviour
{

}
