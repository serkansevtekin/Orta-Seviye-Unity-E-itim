using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class MenuManager : MonoBehaviour
{
    [SerializeField] Vector2 spacing;

    Button mainButton;

    MenuItem[] menuItems;

    bool isExpanded = false;

    Vector2 mainButtonPosition;
    int itemsCount;

    //main btn ile ilgili ayarlar
    [Space]
    [Header("Main btn")]
    [SerializeField] float rotationDuration;
    [SerializeField] Ease rotationEase;

    //Açma kapama ayarları
    [Space]
    [Header("Açma Kapama Ayarları")]
    [SerializeField] float expandDruation;
    [SerializeField] float collapseDuration;
    [SerializeField] Ease expandEase;
    [SerializeField] Ease collapseEase;

    //alpha fade ayarları
    [Space]
    [Header("Alpha Fade Ayarları")]
    [SerializeField] float expandFadeDuration;
    [SerializeField] float collapseFadeDuration;


    void Start()
    {
        itemsCount = transform.childCount - 1;
        menuItems = new MenuItem[itemsCount];

        for (int i = 0; i < itemsCount; i++)
        {
            menuItems[i] = transform.GetChild(i + 1).GetComponent<MenuItem>();
        }

        mainButton = transform.GetChild(0).GetComponent<Button>();
        mainButton.onClick.AddListener(ToggleMenu);
        mainButton.transform.SetAsLastSibling();

        mainButtonPosition = mainButton.transform.position;

        //diğer butonlar main buttonun pozisyona geliyor
        ResetPosition();

    }

    void ResetPosition()
    {
        for (int i = 0; i < itemsCount; i++)
        {
            menuItems[i].transform.position = mainButtonPosition;
        }
    }

    void ToggleMenu()
    {
        isExpanded = !isExpanded;

        if (isExpanded)
        {
            for (int i = 0; i < itemsCount; i++)
            {
                //  menuItems[i].transform .position = mainButtonPosition + spacing * (i + 1);
                menuItems[i].transform.DOMove(mainButtonPosition + spacing * (i + 1), expandDruation) .SetEase(expandEase);
                menuItems[i].GetComponent<CanvasGroup>().DOFade(1, expandFadeDuration).From(0f);


            }
        }
        else
        {
            for (int i = 0; i < itemsCount; i++)
            {
                /*   menuItems[i].transform
                 .position = mainButtonPosition; */

                menuItems[i].transform.DOMove(mainButtonPosition, collapseDuration).SetEase(collapseEase);
                menuItems[i].GetComponent<CanvasGroup>().DOFade(1, collapseFadeDuration).From(0f);
            }
        }
    }

    void OnDestroy()
    {
        mainButton.onClick.RemoveListener(ToggleMenu);
    }
}
