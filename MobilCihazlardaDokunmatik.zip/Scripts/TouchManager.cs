using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;

public class TouchManager : MonoBehaviour
{


    // Update is called once per frame
    void Update()
    {
        //Cihazda dokunmatik ekran yok ise çık
        if (Touchscreen.current == null) return;

        // Aktif dokunuş sayısı
        int touchCount = Touchscreen.current.touches.Count;

        // Hiç dokunuş yok ise çık
        if (touchCount == 0) return;

        // İlk Parmağın  dokunuş  datası
        TouchControl firstTouch = Touchscreen.current.touches[0];

        // Dokunmanın ekrandaki pozisyonu
        Vector2 pos = firstTouch.position.ReadValue();

        //Dokunmanın Evresi (Began , Moved , Ended vb.)
        var phase = firstTouch.phase.ReadValue();

        // Dokunuşun başladığı an
        if (phase == UnityEngine.InputSystem.TouchPhase.Began)
        {
            Debug.Log("Dokunuş başladı. Koordinatlar: " + pos);


            //Ekranın sağ mı sol mu tarafına dokunuldu
            /*   if (pos.x < Screen.width / 2)
              {
                  // Sol taraf
                  Debug.Log("Ekranın sol tarafına dokunuluyor");
              }
              else
              {
                  // Sağ taraf
                  Debug.Log("Ekranın sağ tarafına dokunuluyor");

              } */

        }

        // Parmağın ekranda hareket ettiği an
        if (phase == UnityEngine.InputSystem.TouchPhase.Moved)
        {
            Debug.Log("Parmak sürükleniyor. Koordinatlar: " + pos);

        }


        // Dokunmaya devam ediyormu
        if (phase == UnityEngine.InputSystem.TouchPhase.Stationary)
        {
            Debug.Log("Dokunmaya devamediyormu. Koordinatlar: " + pos);

        }

        // Parmağın ekrandan kalktığı an
        if (phase == UnityEngine.InputSystem.TouchPhase.Ended)
        {
            Debug.Log("Dokunma bitti. Koordinatlar: " + pos);
        }




        //Ekranın sağ mı sol mu tarafına dokunuldu
        if (pos.x < Screen.width / 2)
        {
            // Sol taraf
            Debug.Log("Ekranın sol tarafına dokunuluyor");
        }
        else
        {
            // Sağ taraf
            Debug.Log("Ekranın sağ tarafına dokunuluyor");

        }


        // Ekranda İki Parmak Kontrolü

        if (touchCount == 2)
        {
            TouchControl finger1 = Touchscreen.current.touches[0];
            TouchControl finger2 = Touchscreen.current.touches[1];

            // İki Parmak Arası mesafe
            float distance = Vector2.Distance(finger1.position.ReadValue(),finger2.position.ReadValue());
            Debug.Log("İki parmak arası mesafe" + distance);

        }

    }
}
