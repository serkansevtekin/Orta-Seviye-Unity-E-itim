using UnityEngine;

public class Raycast2 : MonoBehaviour
{
   public LayerMask obstacleMask;

    void OnDrawGizmos()
    {
        float maxUzaklik = 100f;
        RaycastHit hit;

        bool carptimi =Physics.Raycast(transform.position,transform.forward,out hit, obstacleMask);

        if (carptimi)
        {
            Gizmos.color =Color.green;
            Gizmos.DrawRay(transform.position,transform.forward*hit.distance);
        }
        else
        {
            Gizmos.color=Color.red;
            Gizmos.DrawRay(transform.position, transform.forward * maxUzaklik);
        }
    }
}
