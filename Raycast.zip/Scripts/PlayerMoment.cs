using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMoment : MonoBehaviour
{
    public float moveSPeed = 10f;
    Vector3 targetPosition;
    bool isMoving = false;

    InputSystem_Actions iA;
    bool isMovePressed;

    Vector2 mousePos;

    void Awake()
    {
        iA = new InputSystem_Actions();
    }
    void OnEnable()
    {
        iA.Enable();

        iA.Player.Attack.started += OnMoveStart;
        iA.Player.Attack.canceled += OnMoveCanceled;
    }

    private void OnMoveCanceled(InputAction.CallbackContext context)
    {
        isMovePressed = false;
    }

    private void OnMoveStart(InputAction.CallbackContext context)
    {
        isMovePressed = true;
        Vector2 mousePos = Mouse.current.position.ReadValue();
        Ray ray = Camera.main.ScreenPointToRay(mousePos);
        if (Physics.Raycast(ray, out RaycastHit hit))
        {
            if (hit.collider.CompareTag("Ground"))
            {
                targetPosition = new Vector3(hit.point.x, transform.position.y,hit.point.z);
                isMoving=true;
            }
        }
    }

    void Update()
    {
        if (!isMoving) return;



        //ROTATE
        ROTATE();

        //MOVE
        MOVE();
    }

    private void ROTATE()
    {
         //karakterden hedefe giden yönü
        Vector3 targetDirection = targetPosition - transform.position;
        targetDirection.y = 0;

        if (targetDirection != Vector3.zero)
        {
            //Quaternion.LookRotation(targetDirection) -> dönmesi gereken dönüş bilgisini üretir

            Quaternion rotation = Quaternion.LookRotation(targetDirection);
            //Yumşak dönme hareketi
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, 15f * Time.deltaTime);
        }
    }

    private void MOVE()
    {
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSPeed * Time.deltaTime);

        // Vector3.Distance(a,b) -> a noktası ile b noktası arasındaki gerçek (euclidean) mesafeyi verir.
        if (Vector3.Distance(transform.position, targetPosition) < 0.1f)
        {
            isMoving = false;
        }
    }

    void OnDisable()
    {
        iA.Disable();

        iA.Player.Attack.started -= OnMoveStart;
        iA.Player.Attack.canceled -= OnMoveCanceled;
    }

}
