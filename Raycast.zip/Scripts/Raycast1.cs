using UnityEngine;

public class Raycast1 : MonoBehaviour
{
    [SerializeField] private LayerMask obstacleLayer;
    void Update()
    {
        Ray ray = new Ray(transform.position, transform.forward);

        RaycastHit hit; // ışının çarptığı(hit olduğu nesneyi tutacak değişken)

        if (Physics.Raycast(ray, out hit, 100,obstacleLayer,QueryTriggerInteraction.Ignore))
        {
            Debug.DrawLine(ray.origin, hit.point, Color.green);
            Debug.Log(hit.collider.name);
        }
        else
        {
            Debug.DrawLine(ray.origin, ray.origin + ray.direction * 100, Color.red);
        }
    }
}
