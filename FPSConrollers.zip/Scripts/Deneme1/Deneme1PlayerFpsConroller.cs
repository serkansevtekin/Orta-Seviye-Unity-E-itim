using System;
using Unity.Mathematics;
using UnityEngine;

public class Deneme1PlayerFpsConroller : MonoBehaviour
{
    [Header("Speed Settings")]
    [SerializeField] private float walkSpeed = 5f;
    [SerializeField] private float runSpeed = 10f;



    [Header("Gravity Settings")]
    [SerializeField] private float gravity = -9.81f;
    [SerializeField] private float groundOffset = -2f;
    [SerializeField] private float groundCheckDistance;
    [SerializeField] private LayerMask groundLayerMask;
    Vector3 velocityY;


    [Header("Jump Setttings")]
    [SerializeField] private float jumpForce = 10f;



    [Header("Rotation Settings")]
    [SerializeField] private float MouseSensivityX = 10f;
    [SerializeField] private float MouseSensivityY = 10f;



    [Header("Camera and Pith Settings")]
    [SerializeField] private Transform cameraTransform;
    [SerializeField] private float pitchLimit = 80f;
    float currentPitch;


    [Header("Button Presed Control")]
    [SerializeField] private bool isSprintPressed = false;
    [SerializeField] private bool isJumpPressed = false;


    private PlayerInputs playerInputs;
    private CharacterController characterController;

    Vector2 _moveInput;
    Vector2 _lookInput;

    void Awake()
    {
        playerInputs = new PlayerInputs();
        characterController = GetComponent<CharacterController>();
    }

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
    void OnEnable()
    {
        playerInputs.Enable();

        playerInputs.Player.Move.performed += ctx => _moveInput = ctx.ReadValue<Vector2>();
        playerInputs.Player.Move.canceled += ctx => _moveInput = Vector2.zero;

        playerInputs.Player.Sprint.performed += ctx => isSprintPressed = true;
        playerInputs.Player.Sprint.canceled += ctx => isSprintPressed = false;

        playerInputs.Player.Jump.performed += ctx => isJumpPressed = true;
        playerInputs.Player.Jump.canceled += ctx => isJumpPressed = false;

        playerInputs.Player.Look.performed += ctx => _lookInput = ctx.ReadValue<Vector2>();
        playerInputs.Player.Look.canceled += ctx => _lookInput = Vector2.zero;
    }


    void Update()
    {
        HandleMove();

        ApplyGravityAndJump();

        HandleYawRotation();

        HandleCameraPitch();
    }



    private void HandleMove()
    {
        float currenSpeed = isSprintPressed ? runSpeed : walkSpeed;

        Vector3 move = transform.right * _moveInput.x + transform.forward * _moveInput.y;

        if (move.sqrMagnitude > 0.01f)
        {
            move = move.normalized;
        }

        characterController.Move((move * walkSpeed + velocityY) * Time.deltaTime);
    }


    private void ApplyGravityAndJump()
    {
        if (IsGrounded())
        {
            if (velocityY.y < 0.1f)
            {
                velocityY.y = groundOffset;
            }
            if (isJumpPressed)
            {
                velocityY.y += Mathf.Sqrt(jumpForce * -2f * gravity);
                isJumpPressed=false;
            }
        }
        else
        {
            velocityY.y += gravity * Time.deltaTime;
        }
    }

    private bool IsGrounded()
    {
        Vector3 origin = transform.position + Vector3.up * 0.1f;
        float sphereCastRadius = characterController.radius * 0.9f;

        RaycastHit hit;
        bool grounded = Physics.SphereCast(origin, sphereCastRadius, Vector3.down, out hit, groundCheckDistance, groundLayerMask);
        if (grounded)
        {
            Debug.Log(hit.collider.name);
        }

        return grounded;
    }
    
    // yaw -> (horizontal mouse movement) | Handle -> (Her karede aynı işlemi hesaplama) | Rotation -> (Dönüş işlemi)
    private void HandleYawRotation()
    {
        float yaw = _lookInput.x * MouseSensivityX * Time.deltaTime;
        Quaternion deltaYawRotation = Quaternion.Euler(0,yaw,0);
        transform.rotation *= deltaYawRotation;
    }

    // pitch -> (up down movement)
    private void HandleCameraPitch()
    {
        float pitch = -_lookInput.y * MouseSensivityY * Time.deltaTime;
        currentPitch += pitch;
        currentPitch = Mathf.Clamp(currentPitch, -pitchLimit,pitchLimit);
        
        cameraTransform.localRotation = Quaternion.Euler(currentPitch,0,0);
    }


    void OnDisable()
    {
        playerInputs.Disable();
    }
}
