using Unity.Mathematics.Geometry;
using UnityEngine;

public class Deneme2PlayerFpsConroller : MonoBehaviour
{

    [Header("Speed Settings")]
    [SerializeField] private float walkSpeed = 10f;
    [SerializeField] private float runSpeed = 20f;

    [Header("Yaw Rotation Settings")]
    [SerializeField] private float MouseSensivityX = 20f;
    [SerializeField] private float MouseSensivityY = 20f;
    [SerializeField] private Transform ModelTransform;

    [Header("Pitch Rotation Setting")]
    [SerializeField] private Transform cameraTransform;
    [SerializeField] private float pitchLimit = 80f;
    float currentPitch;

    [Header("Gravity Settings")]
    [SerializeField] private float gravity = -9.81f;
    [SerializeField] private float groundOffset = -2f;
    [SerializeField] private float groundCheckDistance = 0.7f;
    [SerializeField] private LayerMask groundLayerMask;
    private Vector3 velocityY;


    [Header("Jump Speed")]
    [SerializeField] private float jumpForce;

    private CharacterController characterController;
    private PlayerInputs _playerInputs;
    Vector2 _moveInput;
    Vector2 _lookInput;

    [Header("Button Presed State")]
    [SerializeField] private bool _isJumpPressed;
    [SerializeField] private bool _isSprintPressed;

    void Awake()
    {
        characterController = GetComponent<CharacterController>();
        _playerInputs = new PlayerInputs();



    }

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
    void OnEnable()
    {
        _playerInputs.Enable();

        _playerInputs.Player.Move.performed += ctx => _moveInput = ctx.ReadValue<Vector2>();
        _playerInputs.Player.Move.canceled += ctx => _moveInput = Vector2.zero;

        _playerInputs.Player.Look.performed += ctx => _lookInput = ctx.ReadValue<Vector2>();
        _playerInputs.Player.Look.canceled += ctx => _lookInput = Vector2.zero;

        _playerInputs.Player.Jump.performed += ctx => _isJumpPressed = true;
        _playerInputs.Player.Jump.canceled += ctx => _isJumpPressed = false;

        _playerInputs.Player.Sprint.performed += ctx => _isSprintPressed = true;
        _playerInputs.Player.Sprint.canceled += ctx => _isSprintPressed = false;


    }


    void Update()
    {
        HandleMove();
        HandleYawRotation();
        HandlePitchRotation();
        AppleGravityAndJump();
    }

    void HandleMove()
    {
        float currenSpeed = _isSprintPressed ? runSpeed : walkSpeed;
        Vector3 move = transform.right * _moveInput.x + transform.forward * _moveInput.y;
        if (move.sqrMagnitude < 0.01f)
        {
            move = move.normalized;
        }

        characterController.Move((move * currenSpeed + velocityY) * Time.deltaTime);
        
    }

    void HandleYawRotation()
    {
        float yaw = _lookInput.x * MouseSensivityX * Time.deltaTime;
        transform.rotation *= Quaternion.Euler(0, yaw, 0);

        if (ModelTransform != null)
        {
            ModelTransform.rotation = Quaternion.Euler(0,transform.eulerAngles.y,0);
        }
    }

    void HandlePitchRotation()
    {
        float pitch = -_lookInput.y * MouseSensivityY * Time.deltaTime;
        currentPitch += pitch;
        currentPitch = Mathf.Clamp(currentPitch, -pitchLimit, pitchLimit);

        cameraTransform.localRotation = Quaternion.Euler(currentPitch, 0, 0);
    }

    void AppleGravityAndJump()
    {
        if (IsGrounded())
        {
            if (velocityY.y < 0.1f)
            {
                velocityY.y = groundOffset;
            }
            if (_isJumpPressed)
            {
                velocityY.y =  Mathf.Sqrt(jumpForce * -2f * gravity);
                _isJumpPressed = false;
            }
        }
        {
            velocityY.y += gravity * Time.deltaTime;
        }
    }

    bool IsGrounded()
    {
        Vector3 origin = transform.position + Vector3.up * 0.1f;
        float sphereCastRadius = characterController.radius * 0.9f;
        RaycastHit hit;
        bool grouded = Physics.SphereCast(origin, sphereCastRadius, Vector3.down, out hit, groundCheckDistance, groundLayerMask);
        if (grouded)
        {
            Debug.Log(hit.collider.name);
        }

        return grouded;
    }


    void OnDisable()
    {
        _playerInputs.Disable();
    }

}
