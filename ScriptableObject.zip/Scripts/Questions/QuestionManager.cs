using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class QuestionManager : MonoBehaviour
{

    public QuestionsData[] questions;

    public TextMeshProUGUI questionText;
    public Button[] optionButtons;

    int currentIndex = 0;

    void Start()
    {
        LoadQuestion();
    }

    void LoadQuestion()
    {
        if(currentIndex>= questions.Length)
        {
            Debug.Log("Sınav bitti");
            DisableButtons();
            return;
        }
        
        QuestionsData currentQuestion = questions[currentIndex];
        questionText.text = currentQuestion.questionTxt;

        for (int i = 0; i < optionButtons.Length; i++)
        {
            int index = i;
            optionButtons[i].GetComponentInChildren<TextMeshProUGUI>().text = currentQuestion.options[i];
            
            optionButtons[i].onClick.RemoveAllListeners();
            optionButtons[i].onClick.AddListener(() => CheckAnswer(index));
        }
    }

    private void CheckAnswer(int selectedIndex)
    {
       if(selectedIndex == questions[currentIndex].correctAnsweIndex)
        {
            Debug.Log("Doğru");
        }
        else
        {
            Debug.Log("Yanlış");
        }

        currentIndex++;
        LoadQuestion();
    }

    void DisableButtons()
    {
        foreach (var button in optionButtons)
        {
            button.interactable = false;
        }
    }
}
