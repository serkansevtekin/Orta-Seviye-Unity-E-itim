using UnityEngine;

[CreateAssetMenu(fileName ="New Question",menuName ="Quiz/Question")]
public class QuestionsData :ScriptableObject
{
    [TextArea]
    public string questionTxt;
    public string[] options = new string[4];
    public int correctAnsweIndex;
}
