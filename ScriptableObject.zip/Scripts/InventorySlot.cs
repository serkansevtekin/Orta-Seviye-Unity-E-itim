using UnityEngine;

public class InventorySlot : MonoBehaviour
{
    public Item currentItem;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Slottaki Item Name: " + currentItem.itemName);
        Debug.Log("Slottaki Item Value: " + currentItem.value.ToString());

    }

    

}
