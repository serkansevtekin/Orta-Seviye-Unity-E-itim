using UnityEngine;

public enum ItemType{
    Weapon,Coin,Potion
}

[CreateAssetMenu(fileName ="GameItem",menuName ="GameItems/Items")]
public class ItemsDatas : ScriptableObject
{
    public string ItemName;
    public int ItemPrice;
    public ItemType ItemTypes;

    [TextArea]
    public string ItemDescription;
    public Sprite ItemSprite;
}
