using System;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ItemManager : MonoBehaviour
{
    public ItemsDatas[] itemsDatas;

    public TextMeshProUGUI[] itemTxts;
    public Image itemSprite;

    public Image[] ItemsButtonImage;
    public Button[] ItemsButtons;


    void Start()
    {
        LoadItemDatas();

        if (itemsDatas.Length > 0)
            ShowItemDetails(0);
    }

    private void LoadItemDatas()
    {
        int count = itemsDatas.Length;
        for (int i = 0; i < count; i++)
        {
            ItemsButtonImage[i].sprite = itemsDatas[i].ItemSprite;

            int index = i;
            ItemsButtons[i].onClick.AddListener(() =>
            {
                ShowItemDetails(index);
            });

        }


    }

    private void ShowItemDetails(int index)
    {
        ItemsDatas data = itemsDatas[index];
        
        itemTxts[0].text = data.ItemName;
        itemTxts[1].text = data.ItemPrice.ToString();
        itemTxts[2].text = data.ItemTypes.ToString();
        itemTxts[3].text = data.ItemDescription;
        
        if (itemsDatas[index].ItemSprite != null)
        {
            itemSprite.sprite = itemsDatas[index].ItemSprite;
        }
        else
        {
            Debug.LogWarning("ItemSprite atanmamış " + itemsDatas[index].ItemSprite);
        }
    }
}
