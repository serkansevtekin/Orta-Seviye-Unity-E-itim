using UnityEngine;

namespace Oyun.OOP.VirtualAndOverride
{
    public class Character
    {
        public virtual void Attack()
        {
            Debug.Log("Karakter Saldırıyor");
        }
    }

    public class Warrior: Character
    {
        public override void Attack()
        {
            //base.Attack(); // Ana sınıftaki kodları çalıştırır

            Debug.Log("Savaşçı kılıncını savuruyor");
        }
    }

    public class Mage : Character
    {
        public override void Attack()
        {
            base.Attack(); // Ana sınıftaki kodları çalıştırır
            Debug.Log("Büyücü büyü yaparak saldırıyor");

        }
    }
}
