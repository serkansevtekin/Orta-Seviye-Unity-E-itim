using UnityEngine;

namespace Oyun.OOP.VirtualAndOverride
{
    public class VirtualOverrideGameManager : MonoBehaviour
    {

        void Start()
        {
            Character warrior = new Warrior();
            Character mage = new Mage();

            warrior.Attack();
            mage.Attack();
        }


    }

}