using UnityEngine;

namespace Oyun.OOP.Kalitim
{
    public class KalitimGameManager : MonoBehaviour
    {

        void Start()
        {
            //  ilgili script base classta MonoBehaviour kullandığı için,
            // sahnedeki game objenin altına component olarak aklemek zorundayız 
            // Yada yeni bir nesne oluşturup altın component olarak eklemek zorundayız
            /*   Player player = gameObject.AddComponent<Player>();
              Enemys enemy = gameObject.AddComponent<Enemys>(); */


            // Boş obje oluştur ve scipti component olarak ekle
            GameObject playerObje = new GameObject("Players");
            Player player = playerObje.AddComponent<Player>();

            GameObject enemyObje = new GameObject("Enemys");
            Enemys enemy = enemyObje.AddComponent<Enemys>(); 

            player.Move();
            player.Jump();


            enemy.Move();
            enemy.Attack();
        }


    }
}
