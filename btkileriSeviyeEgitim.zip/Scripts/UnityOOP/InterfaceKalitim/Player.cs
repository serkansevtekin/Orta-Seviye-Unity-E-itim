using UnityEngine;

namespace Oyun.OOP.Kalitim
{
    public class Player : Character
    {
        public void Jump()
        {
            Debug.Log("Oyuncu Zipliyor");
        }
    }
}
