using UnityEngine;

namespace Oyun.OOP.Kalitim
{
    public class Enemys : Character
    {
        public void Attack()
        {
            Debug.Log("Düşman saldırıyor");
        }
    }

}