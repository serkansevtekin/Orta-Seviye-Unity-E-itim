using UnityEngine;

namespace Oyun.OOP.Kalitim
{
    public class Character : MonoBehaviour
    {
        public int health;
        public void Move()
        {
            Debug.Log(gameObject.name + " Hareket ediyor ");
        }
    }

}