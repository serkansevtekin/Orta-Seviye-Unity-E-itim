using UnityEngine;

namespace Oyun.OOP.Delegates
{
    public class DelegatesGameManager : MonoBehaviour
    {

        // delegate tanımı
        public delegate void TreeCutAction();

        public TreeCutAction onTreeCut;

        void Start()
        {
            onTreeCut += Cut;
            onTreeCut += ParticleCalis;
            onTreeCut += OtherFunc;

            onTreeCut -= Cut;
            
            if (onTreeCut != null)
            {
                onTreeCut();
            }
        }
        void Cut()
        {
            Debug.Log("Tree cut");
        }
        void ParticleCalis()
        {
            Debug.Log("Particle calis");
        }

        void OtherFunc()
        {
            Debug.Log("Başka bir fonk eklendi");
        }
    }

}