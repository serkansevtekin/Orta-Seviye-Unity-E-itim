using UnityEngine;

namespace Oyun.OOP.Event.UnityEvents
{
    public class LightConreoller : MonoBehaviour
    {
        private Light lighth;
        void Awake()
        {
            lighth = GetComponent<Light>();
        }

        void OnEnable()
        {
            TriggeredZone.onTriggered += TrunOnLight;
        }

        void OnDisable()
        {
            TriggeredZone.onTriggered -= TrunOnLight;
        }
        void TrunOnLight()
        {
            lighth.enabled = !lighth.enabled;
        }
    }

}