using UnityEngine;
using UnityEngine.Events;

namespace Oyun.OOP.Event.UnityEvents
{
    public class TriggeredZone : MonoBehaviour
    {
      // Delegate Tanımı
      public delegate void TrigerEvent();

      //event tanımı
      public static event TrigerEvent onTriggered;

        void OnTriggerEnter(Collider other)
        {
            //Event etikle
           onTriggered?.Invoke();
        }

     
    }

}