
namespace Oyun.OOP.InterfaceSozlesme
{
    public interface IDamageable
    {
        void TakeDamage(int amount);
    }
}
