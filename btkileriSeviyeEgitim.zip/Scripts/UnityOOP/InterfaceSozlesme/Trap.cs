using UnityEngine;

namespace Oyun.OOP.InterfaceSozlesme
{
    public class Trap : MonoBehaviour
    {
        public int damageAmount;
        IDamageable damageable;
        void OnTriggerEnter(Collider other)
        {

            damageable = other.GetComponent<IDamageable>();
           if (damageable != null)
           {
            damageable.TakeDamage(damageAmount);;
           }
        }
    }

}