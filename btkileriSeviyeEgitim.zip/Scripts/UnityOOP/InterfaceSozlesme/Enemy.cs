using UnityEngine;

namespace Oyun.OOP.InterfaceSozlesme
{
    public class Enemy : MonoBehaviour, IDamageable
    {
        public int health=100;
        public void TakeDamage(int amount)
        {
            health -= amount;
            Debug.Log("Enemy saldırıya uğradı "+ health);
        }
    }
}
