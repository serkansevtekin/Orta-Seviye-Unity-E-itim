using TMPro;
using Unity.VisualScripting;
using UnityEngine;

namespace Oyun.OOP.Action
{
    public class UIManager : MonoBehaviour
    {
        public TextMeshProUGUI CountText;
        public GameObject PlayerDieText;

        void OnEnable()
        {
            CounterManager.clickCallBackAction += UpdateUICountText;
            CounterManager.playerDieAction += PlayerDieActionFNC;
        }
        void Osable()
        {
            CounterManager.clickCallBackAction -= UpdateUICountText;   
            CounterManager.playerDieAction -= PlayerDieActionFNC;      
        }
         void UpdateUICountText(int counter)
        {
            CountText.text = counter.ToString();
        }

        void PlayerDieActionFNC(bool activeState)
        {
            PlayerDieText.SetActive(activeState);
        }
    }

}