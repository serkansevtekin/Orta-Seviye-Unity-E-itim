using System;
using UnityEngine;

namespace Oyun.OOP.Action
{
    public class CounterManager : MonoBehaviour
{

    public static Action<int> clickCallBackAction;
    public static Action<bool> playerDieAction;
    private bool playerDie= false;
    private int clickCount = 0;

        void OnMouseDown()
        {
            clickCount++;
            Debug.Log(clickCount);

            clickCallBackAction?.Invoke(clickCount);

            if (clickCount >= 10)
            {
                playerDie = true;
                playerDieAction?.Invoke(playerDie);
            }
            else
            {
               playerDie = false;
            }
        }
    }

}