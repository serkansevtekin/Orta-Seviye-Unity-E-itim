using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace Oyun.OOP.SingletonPatter
{
    public class SingletonUIManager : MonoBehaviour
    {
        public TextMeshProUGUI TextSkore;


        void Update()
        {
            TextSkore.text = "Skore: "+ SingletonGameManager.instance.GetScore().ToString();
        }

        public void SkoreArttir()
        {
            SingletonGameManager.instance.IncreaseScore();
        }

        public void GotoOtherScene()
        {
            // bir sonraki sahneye geç
            //SceneManager.LoadScene(); -> Sahneyi yükle
            // SceneManager.GetActiveScene().buildIndex -> şuanki sahneyi bul ve +1 ile bir sonraki sahneye geç
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }
}
