using UnityEngine;

namespace Oyun
{
    public class SingletonGameManager : MonoBehaviour
    {
        public static SingletonGameManager instance;

        private int skore = 0;

        void Awake()
        {
            if (instance != null && instance != this)
            {
                Destroy(gameObject); // bu nesneden birtane daha var ise onları sil
            }

            instance = this;
            DontDestroyOnLoad(gameObject); // Hiç bir zaman yok olma (yok edilemez)
        }

        public void IncreaseScore()
        {
            skore++;
            Debug.Log("Skore: "+ skore);
        }

        public int GetScore()
        {
            return skore;
        }
    }
}
