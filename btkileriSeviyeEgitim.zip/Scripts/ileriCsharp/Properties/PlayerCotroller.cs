using UnityEngine;

public class PlayerCotroller : MonoBehaviour
{
    PlayerHealth playerHealth;

    void Start()
    {
        playerHealth = new PlayerHealth();
        playerHealth.Health = -1000;

        Debug.Log(playerHealth.Health);
    }
}
