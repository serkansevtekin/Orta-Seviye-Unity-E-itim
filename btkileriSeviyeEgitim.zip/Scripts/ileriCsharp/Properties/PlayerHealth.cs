using UnityEngine;

public class PlayerHealth
{
   private int health;

   public int Health
    {
        get
        {
            return health;
        }
        set
        {
            health = Mathf.Clamp(value,0,100);
        }
    }  

    //Prop + tap ile kolayca oluşturulabilir
    public int Can { get; set; }
}
