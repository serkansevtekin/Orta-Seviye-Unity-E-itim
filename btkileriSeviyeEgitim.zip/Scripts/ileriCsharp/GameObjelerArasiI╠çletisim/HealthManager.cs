using UnityEngine;

namespace Oyun.GameObjelerArasiIletisim
{
    public class HealthManager : MonoBehaviour
    {
        private int maxHealth = 50;

        public int GetMaxHealth()
        {
            return maxHealth;
        }
    }
}
