using UnityEngine;

namespace Oyun.GameObjelerArasiIletisim
{

    public class ObjArasiIletisimPlayer : MonoBehaviour
    {
        GameObject[] dusmanlar;
        HealthManager healthManager;
        private GameObject healthPack;

        void Awake()
        {
            // Maliyeti çok yüksek (En iyisi inspector dan bağlamak)
            healthManager = FindAnyObjectByType<HealthManager>();

        }

        void Start()
        {
            /*
            Bu yöntem makul ama daha perdormanslısı (Çok mantıklı bir yöntem)
          
            public static List<GameObject> aktifDusmanlar = new List<GameObject>();
          
            void OnEnable()
            {
            GameManager.aktifDusmanlar.Add(gameObject);
            }
            
            void OnDisable()
            {
            GameManager.aktifDusmanlar.Remove(gameObject);
            }

            */
            dusmanlar = GameObject.FindGameObjectsWithTag("Enemy");
            foreach (GameObject dusman in dusmanlar)
            {
                Debug.Log(dusman.name);
            }

            healthPack = GameObject.Find("HealthPack"); // sahnedeki isim ile bulma

            healthPack = GameObject.FindWithTag("Health"); // nesneyi tag ile bulma



            if (healthPack != null)
            {
                Debug.Log("Nesne Bulundu");
            }
            else
            {
                Debug.Log("Bulunamadı");
            }

            //Script'ten scripte ulaşma

            Debug.Log(healthManager.GetMaxHealth());

        }
    }
}
