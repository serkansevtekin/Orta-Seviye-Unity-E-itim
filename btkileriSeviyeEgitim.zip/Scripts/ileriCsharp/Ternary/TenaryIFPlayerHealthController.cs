using UnityEngine;

public class TenaryIFPlayerHealthController : MonoBehaviour
{
    public int health = 50;

    private string status;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            health -= 10;

            /* if (health > 0)
            {
                status = " Hayatta";
            }
            else
            {
                status = "Öldü";
            } */

            status = health > 0 ? "Hayatta" : "Öldü";
            Debug.Log(status);
        }
    }
}
