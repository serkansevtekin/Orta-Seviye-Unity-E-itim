using UnityEngine;

public class StaticDegiskeneUlas : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        GameManager.skor = 200;

        Debug.Log(MathHelper.KareAl(10));
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
           // collision.gameObject.GetComponent<EnemyStaticOrnek>().life--;
           EnemyStaticOrnek.life--;// Aynı anda tüm  EnemyStaticOrnek.life aynı anda etkilenir
        }
    }
}
