public class MathHelper
{
    public static int KareAl(int number)
    {
        return number * number;
    }
}