using UnityEngine;

public class EnemyStaticOrnek : MonoBehaviour
{
    public static int life = 1;

    void Update()
    {
        if (life <= 0)
        {
            Destroy(gameObject);
        }
    }
}
