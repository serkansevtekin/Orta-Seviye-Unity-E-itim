using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static int skor = 100;
}
