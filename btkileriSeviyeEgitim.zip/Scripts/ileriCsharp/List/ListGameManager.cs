using System.Collections.Generic;
using UnityEngine;

public class ListGameManager : MonoBehaviour
{
   List<string> envanter = new List<string>();

    void Start()
    {
        envanter.Add("Kılıç");
        envanter.Add("Kalkan");
        envanter.Add("İksir");

      

        envanter.Remove("İksir");

        envanter.Insert(1,"Ok");

        foreach(string item in envanter)
        {
            Debug.Log(item);
        }
        if (envanter.Contains("Kılıç"))
        {
            Debug.Log("Kılıç var");
        }
        else
        {
            Debug.Log("Kılıç bulunamadı");
            
        }
    }
}
