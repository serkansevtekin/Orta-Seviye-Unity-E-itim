using UnityEngine;

namespace Oyun.Dusman
{
    public class Savasci
    {
        public void Savunma()
        {
            Debug.Log("Dusman savunma yapıyor");
        }
    }

}