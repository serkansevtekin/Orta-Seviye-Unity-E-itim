using UnityEngine;

namespace Oyun.Kahraman
{
    public class Savasci
    {
        public void Savunma()
        {
            Debug.Log("Kahraman savunma yapıyor");
        }
    }

}