using UnityEngine;
using KahramanSavasci = Oyun.Kahraman.Savasci;
using DusmanSavasci = Oyun.Dusman.Savasci;
public class NameSpaceGameManager : MonoBehaviour
{

    /*   Oyun.Kahraman.Savasci kahramanS = new Oyun.Kahraman.Savasci();
      Oyun.Dusman.Savasci dusmanS = new Oyun.Dusman.Savasci(); */

    KahramanSavasci kahramanS = new KahramanSavasci();
    DusmanSavasci dusmanS = new DusmanSavasci();


    void Start()
    {
        kahramanS.Savunma();
        dusmanS.Savunma();
    }


}
