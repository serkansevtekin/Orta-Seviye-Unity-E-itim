using System.Collections.Generic;
using UnityEngine;

public class DictionaryGameManager : MonoBehaviour
{
    Dictionary<string, int> skorTablosu = new Dictionary<string, int>();
    Dictionary<int, string> oyuncular = new Dictionary<int, string>
    {
        {1,"Oyuncu 1"},
        {2, "Oyuncu 2"}
    };

    void Start()
    {
        skorTablosu.Add("ahmet", 1500);
        skorTablosu.Add("hakan",8000);

        skorTablosu.Remove("ahmet");
        if (skorTablosu.ContainsKey("ahmet"))
        {
            Debug.Log(skorTablosu["ahmet"]);
        }
        else
        {
            Debug.Log("Ahmet bulunamadı");
        }

        foreach (var item in oyuncular)
        {
            Debug.Log($"{item.Key} ve {item.Value}");
        }

    }
}
