using UnityEngine;

public class PlayerMethodOverloadingScript : MonoBehaviour
{
    public int Can = 100;

    public void HasarAl(int hasarMiktari)
    {
        Can -= hasarMiktari;
    }

    public void HasarAl(int hasarMiktari, string buyuTipi)
    {
        Can -= hasarMiktari;
        Debug.Log("Oyuncu "+  buyuTipi +" büyüsünden dolayı hasar aldı");
    }
}
