using UnityEngine;

public class EnemyMethodOverloading : MonoBehaviour
{
    public PlayerMethodOverloadingScript hedefPlayer;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            hedefPlayer.HasarAl(10);
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
             hedefPlayer.HasarAl(25,"Magic Ball");
        }
    }
}
