using UnityEngine;
using DG.Tweening;
using TMPro;
public class DoTweenManager : MonoBehaviour
{
   /*  public Transform player; */

    /*   public float yHeight;
      public float animationDuration;
      public Ease ease;
      public float animationDelay;
      public int loopCount;
      public LoopType loopType; */
/* 
   public Vector3[] paths;
    public float animationDuration;
    public PathType pathType;
    public PathMode pathMode;
 */
    public MeshRenderer mr;

    public TextMeshProUGUI metinText;
    public string yazilacakMetin="Daktilo Efekti";
    public float yazmaSuresi=3f;
    void Start()
    {


    /*     player.DOPath(paths,animationDuration,pathType,pathMode,10);

        mr.material.DOColor(Color.blue,2f); */
       // mr.material.DOColor(GetRandomColor(),1f).SetLoops(-1);

       /*  player.DOMoveY(yHeight, animationDuration)
        .SetEase(ease)
        .SetDelay(animationDelay)
        .SetLoops(loopCount, loopType)
        .OnStepComplete((AdimTamammi)); */

        int harfSayisi = 0;
        DOTween.To(() => harfSayisi, x =>
        {
            harfSayisi = x;
            metinText.text =yazilacakMetin.Substring(0,harfSayisi);

        },yazilacakMetin.Length,yazmaSuresi);
    }

    /*    void AdimTamammi()
       {
           Debug.Log("Adım Tamamlandı");
       } */



   /*  Color GetRandomColor()
    {
        return new Color(Random.Range(0f,1f),Random.Range(0f,1f),Random.Range(0f,1f),1f);
    } */
}
