using System;
using UnityEngine;
using UnityEngine.InputSystem;
public class BasicFpsController : MonoBehaviour
{
    CharacterController controller;
    private InputSystem_Actions inputActions;



    [Header("Movement Settings")]
    [SerializeField] private float MoveSpeed = 5f;
    [SerializeField] private float runspeed=10f;

    [Header("Rotation Settings")]
    [SerializeField] private float RotationSpeedX = 30f;
    [SerializeField] private float RotationSpeedY = 20f;

    [Header("Cammera Settings")]
    [SerializeField] Transform cameraTransform;
    [SerializeField] float pitchLimit = 80f;

    [Header("Gravity Settings")]
    [SerializeField] float gravity = -9.81f;
    [SerializeField] float groundedOffset = -0.1f;
    Vector3 velocity;

    [Header("Jump Settings")]
    [SerializeField] float JumpForce = 5f;
    bool jumpPresed = false;

    [Header("Ground Control Setting")]
    [SerializeField] float groundCheckDistance = 0.3f;
    [SerializeField] LayerMask groundMask;
    [SerializeField] bool isGrounded;

    
    Vector2 moveInput;
    Vector2 lookInput;
    bool isSprinting=false;

    float currentPitch;

    

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        inputActions = new InputSystem_Actions();


    }
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
    void OnEnable()
    {
        inputActions.Player.Enable();

        inputActions.Player.Move.performed += ctx => moveInput = ctx.ReadValue<Vector2>();
        inputActions.Player.Move.canceled += ctx => moveInput = Vector2.zero;

        inputActions.Player.Look.performed += ctx => lookInput = ctx.ReadValue<Vector2>();
        inputActions.Player.Look.canceled += ctx => lookInput = Vector2.zero;

        inputActions.Player.Jump.performed += ctx => jumpPresed = true;
        inputActions.Player.Jump.canceled += ctx => jumpPresed = false;

        inputActions.Player.Sprint.performed += ctx => isSprinting = true;
        inputActions.Player.Sprint.canceled += ctx => isSprinting =false;
        
    }

    void Update()
    {
        // hareket için gerekli kodlar
        HandleMovement();

        //sağ sola dönüş için kodlar
        HandelRotation();

        //Aşağı yukarı bakış
        HandleCameraPitch();

        //Yerçekimi uygula ve yerde ise zıpla
        AppleGravityAndJump();
    }

    private void HandleMovement()
    {   
        float currentSpeed = isSprinting ? runspeed : MoveSpeed;

        Vector3 move = transform.right * moveInput.x + transform.forward * moveInput.y;

        if (move.sqrMagnitude > 0.01f)
        {
            move = move.normalized;
        }
        // controller.Move(move * MoveSpeed * Time.deltaTime);
        controller.Move((move * currentSpeed + velocity) * Time.deltaTime);
    }
    private void HandleCameraPitch()
    {
        float pitch = -lookInput.y * RotationSpeedY * Time.deltaTime;

        currentPitch += pitch;

        currentPitch = Math.Clamp(currentPitch, -pitchLimit, pitchLimit);

        cameraTransform.localRotation = Quaternion.Euler(currentPitch, 0, 0);
    }

    private void HandelRotation()
    {
        float yaw = lookInput.x * RotationSpeedX * Time.deltaTime;
        Quaternion deltaRotation = Quaternion.Euler(0, yaw, 0);

        transform.rotation *= deltaRotation;
    }

    private void AppleGravityAndJump()
    {
        CheckGrounded();

        if (isGrounded)
        {
            if (velocity.y < 0)
            {
                velocity.y = groundedOffset; // Küçük negatif değer ile yer yapıştır
            }

            if (jumpPresed)
            {
                velocity.y = Mathf.Sqrt(JumpForce * -2f * gravity);
                jumpPresed = false;
            }
        }
        else
        {
            velocity.y += gravity * Time.deltaTime;
        }

    }

    private void CheckGrounded()
    {
        Vector3 startPos = transform.position + Vector3.up * 0.1f;
        isGrounded = Physics.Raycast(startPos, Vector3.down, groundCheckDistance, groundMask);
    }

    void OnDisable()
    {
        inputActions.Player.Disable();

    }

}
