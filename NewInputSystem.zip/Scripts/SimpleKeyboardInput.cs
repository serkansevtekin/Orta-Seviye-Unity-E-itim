using UnityEngine;
using UnityEngine.InputSystem;

public class SimpleKeyboardInput : MonoBehaviour
{

   // Keyboard.current,Mouse.current

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Keyboard.current.spaceKey.wasPressedThisFrame)
        {
            Debug.Log("Boşlu tuşuna basıldı");
        }

        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            Debug.Log("Mouse sol buton tıklandı");
            
        }
       Vector2 poz = Mouse.current.position.ReadValue();

       Debug.Log("Mouse pozisyonu "+ poz);
    }
}
