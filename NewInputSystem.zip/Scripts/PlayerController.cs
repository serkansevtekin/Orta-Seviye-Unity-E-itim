using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    InputSystem_Actions inputActions;
    private Vector2 moveInput;

    private bool JumpHandle;
    private bool AttackHandle;
    void Awake()
    {
        inputActions = new InputSystem_Actions();
    }
    void OnEnable()
    {
        inputActions.Player.Enable();

      //  inputActions.Player.Move.performed += OnMovePerformed;
       // inputActions.Player.Move.canceled += OnMoveCanceled;

       //kısa yazım ekstra method oluşturmaya gerek yok
       inputActions.Player.Move.performed += ctx => moveInput = ctx.ReadValue<Vector2>();
       inputActions.Player.Move.canceled += ctx => moveInput = Vector2.zero;

       inputActions.Player.Jump.performed += ctx => JumpHandle = true;
       inputActions.Player.Jump.canceled += ctx => JumpHandle = false;

       inputActions.Player.Attack.performed += ctx => AttackHandle = true;
       inputActions.Player.Attack.canceled += ctx => AttackHandle = false;

    }

    private void Jump()
    {
       Debug.Log("Space tuşuna basıldı zıplandı");
    }

    void OnDisable()
    {
        inputActions.Player.Disable();

      //  inputActions.Player.Move.performed -= OnMovePerformed;
      //  inputActions.Player.Move.canceled -= OnMoveCanceled;

     

    }

/*     void OnMovePerformed(InputAction.CallbackContext context)
    {
        moveInput = context.ReadValue<Vector2>();
    } */

 /*    private void OnMoveCanceled(InputAction.CallbackContext context)
    {
        moveInput = Vector2.zero;
        
    } */


    void Update()
    {
        Vector3 move = new Vector3(moveInput.x, 0,moveInput.y);
        transform.Translate(move * 10f * Time.deltaTime);

        if (JumpHandle == true)
        {
            Debug.Log("Zıplandı");
            
        }
     

         if (AttackHandle == true)
        {
            Debug.Log("Atak yapıldı");
            
        }
  
    }


}
