

using System.Collections.Generic;
using UnityEngine;

public class BulletPool : MonoBehaviour
{
    // Pool’daki mermeleri saklamak için kuyruk
    private Queue<GameObject> pooledObjects;

    // Hangi prefab kullanılacak
    [SerializeField] private GameObject bulletPrefab;

    // Pool’daki toplam mermi sayısı
    [SerializeField] private int poolSize;

    void Awake()
    {
        pooledObjects = new Queue<GameObject>();

        // Poolu önceden oluştur, objeleri instantiate et ve kuyruğa ekle
        for (int i = 0; i < poolSize; i++)
        {
            GameObject obj = Instantiate(bulletPrefab, transform); // Prefab’dan nesne oluştur , Pool objesinin child yap

            obj.SetActive(false); // Başlangıçta pasif

            pooledObjects.Enqueue(obj);  // Kuyruğa ekle
        }
    }

    // Pool’dan mermi almak için, pozisyon, rotasyon ve global yönü ver
    public GameObject GetPooledObject(Vector3 position, Quaternion rotation, Vector3 globalDirection)
    {
        if (pooledObjects.Count == 0) return null; // Pool boşsa null dön


        GameObject bullet = pooledObjects.Dequeue(); // Kuyruktan mermi al
        bullet.transform.position = position; // Pozisyonu set et
        bullet.transform.rotation = rotation;  // Rotasyonu set et

        // BulletMove scriptini al ve pool + yönü ayarla
        BulltetMove bm = bullet.GetComponent<BulltetMove>();
        if (bm != null)
        {
            bm.SetPool(this); // Pool referansını set et
            bm.SetDirection(globalDirection);  // Hareket yönünü set et
        }

        bullet.SetActive(true);    // Mermiyi aktif yap

        return bullet;
    }

    // Mermiyi pool’a geri vermek için
    public void ReturnedBullet(GameObject bullet)
    {
        bullet.SetActive(false);      // Mermiyi pasif yap
        pooledObjects.Enqueue(bullet); // Kuyruğa geri ekle
    }

}
