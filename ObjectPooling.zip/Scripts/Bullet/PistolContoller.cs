using System.Collections;
using UnityEngine;

public class PistolContoller : MonoBehaviour
{

    // Hangi pool kullanılacak
    [SerializeField] private BulletPool bulletPool;

    // Mermilerin spawn edileceği nokta (silah namlusu vb.)
    [SerializeField] private Transform spawnPoint;

    // Ateş hızı (saniyede bir mermi için bekleme süresi)
    [SerializeField] private float FireRate;

    // FireRate kontrolü için timer
    float FireRateTimer = 0;

    // Yeni Input System referansı
    InputSystem_Actions iAction;

    // Ateş tuşunun basılı olup olmadığını tutar
    private bool isAttackPressed = false;

    void Awake()
    {
        // Input System objesini oluştur
        iAction = new InputSystem_Actions();
    }

    void OnEnable()
    {
        iAction.Enable();

        // Ateş tuşu basıldığında isAttackPressed = true
        iAction.Player.Attack.started += ctx => isAttackPressed = true;

        // Ateş tuşu bırakıldığında isAttackPressed = false
        iAction.Player.Attack.canceled += ctx => isAttackPressed = false;

    }

    void Update()
    {

        // Her frame mermiyi ateşlemeyi kontrol et
        Shoot();


    }

    void Shoot()
    {
        // FireRate timer varsa düşür
        if (FireRateTimer > 0)
        {
            FireRateTimer -= Time.deltaTime;
        }

        // Ateş tuşuna basılmış ve cooldown süresi dolmuşsa mermi spawn et
        if (isAttackPressed && FireRateTimer <= 0f)
        {
            // Pool’dan mermi al, pozisyon, rotasyon ve global yön ver
            GameObject obj = bulletPool.GetPooledObject(spawnPoint.position, spawnPoint.rotation, spawnPoint.forward);

            // FireRate timer'ını resetle
            FireRateTimer = FireRate;
        }



    }


    void OnDisable()
    {
         // Input System devre dışı bırak
        iAction.Disable();

        // Event listener’ları temizle
        iAction.Player.Attack.started -= ctx => isAttackPressed = true;
        iAction.Player.Attack.canceled -= ctx => isAttackPressed = false;
    }



    /*   void Start()
      {
          StartCoroutine(nameof(BulletSpawnRoutuneFNC));
      }

      public IEnumerator BulletSpawnRoutuneFNC()
      {
          while (true)
          {
              GameObject obj = bulletPool.GetPooledObject();

              obj.transform.position = spawnPoint.position;

              yield return new WaitForSeconds(bulletLifeTime);
          }
      } */
}
