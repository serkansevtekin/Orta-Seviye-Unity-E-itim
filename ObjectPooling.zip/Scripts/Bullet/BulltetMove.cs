using UnityEngine;

public class BulltetMove : MonoBehaviour
{
    // Bu mermiyi hangi BulletPool yönetecek
    private BulletPool bulletPool;
    [SerializeField] private float bulletSpeed = 10f;

    // Merminin hareket yönü (global yön)
    private Vector3 moveDirection = Vector3.forward;

     // Pool referansını spawn sırasında set etmek için kullanılır
    public void SetPool(BulletPool pool)
    {
        bulletPool = pool;
    }

    // Mermi yönünü spawn sırasında set et
    public void SetDirection(Vector3 direction)
    {
        moveDirection = direction.normalized; // normalize ederek sabit hız sağlar
    }

    // Update is called once per frame
    void Update()
    {
         // Mermiyi global sahne yönünde hareket ettir
        // Space.World kullanıldığı için prefab rotation'ı önemsiz
        transform.Translate(moveDirection * bulletSpeed * Time.deltaTime,Space.World);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            // Pool referansı varsa geri ver, yoksa objeyi yok et
            if (bulletPool != null)
                bulletPool.ReturnedBullet(gameObject);
            else
                Destroy(gameObject);
        }
    }
}
