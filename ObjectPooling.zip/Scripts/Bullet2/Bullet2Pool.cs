using System.Collections.Generic;
using UnityEngine;

public class Bullet2Pool : MonoBehaviour
{

    private Queue<GameObject> pooledBullet = new Queue<GameObject>();
    [SerializeField] private GameObject bulletPrefab;
    [SerializeField] private int poolSize = 0;


    void Awake()
    {
        for (int i = 0; i < poolSize; i++)
        {
            GameObject objBullet = Instantiate(bulletPrefab, transform);
            objBullet.SetActive(false);

            Bullet2Move b2m = objBullet.GetComponent<Bullet2Move>();
            if (b2m !=null)
            {
                b2m.SetPool(this);
            }

            pooledBullet.Enqueue(objBullet);
        }
    }



    public GameObject GetPooledObject(Vector3 spawnPos, Quaternion spawnRot)
    {
        if (pooledBullet.Count == 0) return null;

        GameObject objBullet = pooledBullet.Dequeue();
        objBullet.SetActive(true);
        objBullet.transform.position = spawnPos;
        objBullet.transform.rotation = spawnRot;

        return objBullet;
    }

    public void ReturnedPoolObject(GameObject objBullet)
    {
      objBullet.SetActive(false);
      pooledBullet.Enqueue(objBullet);
    }




}
