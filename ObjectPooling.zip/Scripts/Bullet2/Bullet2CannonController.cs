using System;
using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class Bullet2CannonController : MonoBehaviour
{


    [SerializeField] private Bullet2Pool bullet2Pool;
    [SerializeField] private Transform spawnedPoint;
    [SerializeField] private float fireRate = 0.5f;
    private float fireTime = 0f;

    InputSystem_Actions iA;

    private bool isAttac = false;
    GameObject objB;

    void Awake()
    {
        iA = new InputSystem_Actions();
    }
    void OnEnable()
    {
        iA.Enable();
        iA.Player.Attack.started += ctx => isAttac = true;
        iA.Player.Attack.canceled += ctx => isAttac = false;
    }

    void Update()
    {
        Shoot();
    }

    private void Shoot()
    {
        if (fireTime > 0)
        {
            fireTime -= Time.deltaTime;
        }

        if (isAttac && fireTime <= 0)
        {
            objB = bullet2Pool.GetPooledObject  (spawnedPoint.position, spawnedPoint.rotation);
            if (objB != null)
            {
                objB.GetComponent<Bullet2Move>().Launch(spawnedPoint.forward);
            }
            fireTime = fireRate;
        }

    }

    void OnDisable()
    {
        iA.Disable();
        iA.Player.Attack.started -= ctx => isAttac = true;
        iA.Player.Attack.canceled -= ctx => isAttac = false;
    }










}
