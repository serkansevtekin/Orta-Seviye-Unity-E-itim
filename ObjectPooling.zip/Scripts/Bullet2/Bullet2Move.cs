using UnityEngine;

public class Bullet2Move : MonoBehaviour
{

    [SerializeField] float bulletSpeed = 20f;
    Rigidbody rb;
    Bullet2Pool bulletPool;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    public void SetPool(Bullet2Pool pool) => bulletPool = pool;
    public void Launch(Vector3 direction) => rb.linearVelocity = direction * bulletSpeed;

    void OnTriggerEnter(Collider other)
    {

        if (bulletPool != null)
        {
            bulletPool.ReturnedPoolObject(gameObject);
        }

    }








}
