using System.Collections.Generic;
using UnityEngine;

public class Bullet3Pool : MonoBehaviour
{
    private Queue<GameObject> poolBullet;
    [SerializeField] private GameObject bulletPrefab;
    [SerializeField] private int poolSize = 0;
   
    void Awake()
    {
        poolBullet = new Queue<GameObject>();

        for (int i = 0; i < poolSize; i++)
        {
            GameObject objBullet = Instantiate(bulletPrefab,transform);
            objBullet.SetActive(false);

            Bullet3Move b3m = objBullet.GetComponent<Bullet3Move>();
            if (b3m != null)
            {
                b3m.SetPool(this);
            }

            poolBullet.Enqueue(objBullet);
        }
    }


    public GameObject GetPooledObject(Vector3 spawnerPos, Quaternion spawnerRot)
    {
        if (poolBullet.Count == 0) return null;
 
        GameObject objBullet = poolBullet.Dequeue();
        objBullet.transform.position=spawnerPos;
        objBullet.transform.rotation = spawnerRot;

        objBullet.SetActive(true);

        return objBullet;
    }

    public void ReturnPooledObject(GameObject objBullet)
    {
        objBullet.SetActive(false);
        poolBullet.Enqueue(objBullet);
    }
}
