using System.Collections;
using UnityEngine;

public class Bullet3Move : MonoBehaviour
{
    Bullet3Pool bullet3Pool;
    [SerializeField] private float bulletSpeed = 10f;
    [SerializeField] private float lifeTime = 3f;

    Coroutine lifeRoutine;
    Rigidbody rb;


    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    public void SetPool(Bullet3Pool pool) => bullet3Pool = pool;

    public void Launcher(Vector3 direction) => rb.linearVelocity = direction.normalized * bulletSpeed;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            bullet3Pool.ReturnPooledObject(gameObject);
        }
    }


    void OnEnable()
    {
        lifeRoutine = StartCoroutine(nameof(LifeTimerFNC));
    }
    IEnumerator LifeTimerFNC()
    {
        yield return new WaitForSeconds(lifeTime);

        bullet3Pool.ReturnPooledObject(gameObject);

    }
    void OnDisable()
    {
        if (lifeRoutine != null)
        {
            StopCoroutine(nameof(LifeTimerFNC));
        }
    }
}
