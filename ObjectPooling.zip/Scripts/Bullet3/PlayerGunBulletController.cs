using UnityEngine;

public class PlayerGunBulletController : MonoBehaviour
{
    [SerializeField] Bullet3Pool bullet3Pool;
    [SerializeField] Transform spawnedObjecT;
    [SerializeField] float fireRate = 1f;
    float fireTime = 0f;

    InputSystem_Actions iA;
    private Bullet3Move bullet3Move;

    GameObject objG;
    private bool isAttac = false;

    void Awake()
    {
        iA = new InputSystem_Actions();
    }
    void OnEnable()
    {
        iA.Enable();

        iA.Player.Attack.started += ctx => isAttac = true;
        iA.Player.Attack.canceled += ctx => isAttac = false;

    }

    void Update()
    {
        Shoot();
    }

    private void Shoot()
    {
        if (fireTime > 0)
        {
            fireTime -= Time.deltaTime;
        }

        if (isAttac && fireTime <= 0)
        {
            objG = bullet3Pool.GetPooledObject(spawnedObjecT.transform.position, spawnedObjecT.transform.rotation);
            if (objG != null)
            {
                objG.GetComponent<Bullet3Move>().Launcher(spawnedObjecT.forward);
            }
            fireTime = fireRate;
        }

    }

    void OnDisable()
    {
        iA.Disable();

        iA.Player.Attack.started -= ctx => isAttac = true;
        iA.Player.Attack.canceled -= ctx => isAttac = false;
    }
}
