using System;
using UnityEngine;

public class BananaController : MonoBehaviour
{
    [Header("Speed Settig")]
    [SerializeField] private float walkSpeed;
    [SerializeField] private float runSpeed;
    float currenSpeed;

    CharacterController characterController;
    InputSystem_Actions inputSystemAction;
    Animator animator;

    Vector2 moveInput;
    Vector3 movementDirection;

    bool isRuning = false;
    void Awake()
    {
        characterController = GetComponent<CharacterController>();
        inputSystemAction = new InputSystem_Actions();
        animator = GetComponentInChildren<Animator>();
        currenSpeed = walkSpeed;
    }
    
    void OnEnable()
    {
        inputSystemAction.Enable();

        inputSystemAction.Player.Move.performed += ctx => moveInput = ctx.ReadValue<Vector2>();
        inputSystemAction.Player.Move.canceled += ctx => moveInput = Vector2.zero;

        inputSystemAction.Player.Sprint.performed += ctx =>
        {
            currenSpeed = runSpeed;
            isRuning = true;
        };
        inputSystemAction.Player.Sprint.canceled += ctx =>
        {
            currenSpeed = walkSpeed;
            isRuning = false;
        };

    }
    void Update()
    {
        HandleMovement();
        CheckAnimation();
    }


    void HandleMovement()
    {
       
        Vector3 move = transform.right * moveInput.x + transform.forward * moveInput.y;

        if (move.magnitude > 0.01f)
        {
            move = move.normalized;
        }

        characterController.Move(move * currenSpeed * Time.deltaTime);
    }

    private void CheckAnimation()
    {
        movementDirection = new Vector3(moveInput.x, 0, moveInput.y);
        float xVelocity = Vector3.Dot(movementDirection.normalized,transform.right);
        float zVelocity = Vector3.Dot(movementDirection.normalized,transform.forward);

        animator.SetFloat("xVelocity",xVelocity,0.1f,Time.deltaTime);
        animator.SetFloat("zVelocity",zVelocity,0.1f,Time.deltaTime);

        bool playerRunAnim = isRuning && movementDirection.magnitude >0;
        animator.SetBool("isRuning",isRuning);
    }


    void OnDisable()
    {
        inputSystemAction.Disable();

    }
}
