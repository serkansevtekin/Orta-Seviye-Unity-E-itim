using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

public class PLayerAnimationController : MonoBehaviour
{
    Animator animator;
    InputSystem_Actions inputActions;

    bool isRunPressed = false;

    Vector2 inputMove;

    void Awake()
    {
        animator = GetComponentInChildren<Animator>();
        inputActions = new InputSystem_Actions();
    }

    void OnEnable()
    {
        inputActions.Enable();

        inputActions.Player.Move.performed += ctx => inputMove = ctx.ReadValue<Vector2>();
        inputActions.Player.Move.canceled += ctx => inputMove = Vector2.zero;

        inputActions.Player.Sprint.performed += ctx => isRunPressed = true;
        inputActions.Player.Sprint.canceled += ctx => isRunPressed = false;
    }
  

    void Update()
    {
        UpdateAnimation();
    }

    private void UpdateAnimation()
    {
        bool isWalkingForward = inputMove.y > 0.01f;
        bool isWalking = isWalkingForward;
        bool isRuning = isWalkingForward && isRunPressed;

        animator.SetBool("isWalking", isWalking);
        animator.SetBool("isRuning", isRuning);
    }

    void OnDisable()
    {
        inputActions.Disable();
    }
}